"""
SIG Algothon trading algorithm.

Strategy: statistical arbitrage on the small set of instrument pairs that
survived Bonferroni-corrected Engle-Granger cointegration testing on the
750-day training file (1,275 pairs tested; only 6 significant at
p < 0.05/1275). Those 6 were validated out-of-sample: hedge ratios fit on
the first half of the training data, traded on the untouched second half,
all 6 profitable. A further 2 instruments (MTNS, FARS) have individually
stationary price levels and trade a simple standalone mean-reversion rule.

Everything else (including ALGO/asset 0) is left flat: ALGO tracks an
equal-weighted basket of the other 50 (R^2 ~0.99 in returns) but that
relationship is purely contemporaneous (no lead-lag) and the basket spread
is NOT cointegrated (Engle-Granger p=0.65), so there is no validated edge
to trade there. Don't invent a signal that isn't backed by the data.

Rename this file to <yourTeamName>.py before submitting.
"""

import numpy as np
from arch import arch_model
import pandas as pd

# ---------------------------------------------------------------------------
# Instrument index map (fixed order, matches the competition's asset 0-50):
#  0 ALGO   1 AENO   2 LSST   3 SRNA   4 ELLT   5 AMRP   6 OTCS   7 HETT
#  8 HUXZ   9 DUCT  10 SMAH  11 NPCK  12 MSDP  13 EORC  14 CUBO  15 HRET
# 16 ANSO  17 DIHO  18 RTTH  19 SPLZ  20 NWIG  21 MMBT  22 MDGI  23 AGVF
# 24 RRES  25 CTGI  26 ALUT  27 ACAC  28 SRTX  29 GARI  30 RCRI  31 ACIX
# 32 CCNS  33 MTNS  34 IHOZ  35 NAYO  36 FWWG  37 EELT  38 HRND  39 AETS
# 40 ULXY  41 BLBT  42 BENI  43 ITPA  44 HTRK  45 NGTE  46 ILVX  47 FCSG
# 48 FARS  49 MHRM  50 EAFC
# ---------------------------------------------------------------------------

N_INST = 51
POSITION_LIMITS = np.array([100_000.0] + [10_000.0] * 50)

# Bonferroni-significant cointegrated pairs: spread = price_A - hedge*price_B - const
PAIRS = [
    (10, 46),  # SMAH ~ ILVX   (EG p=3.4e-9)
    (1, 20),   # AENO ~ NWIG   (EG p=3.7e-9)
    (8, 27),   # HUXZ ~ ACAC   (EG p=1.2e-8)
    (7, 40),   # HETT ~ ULXY   (EG p=2.1e-7)
    (25, 37),  # CTGI ~ EELT   (EG p=7.9e-6, both legs individually stationary too)
    (18, 35),  # RTTH ~ NAYO   (EG p=3.5e-5)
]

# Individually mean-reverting instruments not already covered by a pair above
# (ULXY, CTGI, EELT are also individually stationary but already traded via PAIRS)
SOLO_MEANREV = [33, 48]  # MTNS, FARS

HEDGE_WINDOW = 300     # long trailing window for a stable hedge-ratio estimate
Z_WINDOW = 40          # short trailing window for the entry/exit z-score
ENTRY_Z = 1.3
EXIT_Z = 0.3

SOLO_WINDOW = 60
SOLO_ENTRY_Z = 1.5
SOLO_EXIT_Z = 0.5

ALLOC_FRACTION = 0.95  # fraction of the per-instrument cap deployed on a full signal

MIN_DAYS_PAIRS = Z_WINDOW + 2
MIN_DAYS_SOLO = 20

# Module-level state persisted across sequential daily calls (standard for this
# style of harness: the module stays loaded and getMyPosition is called once per
# day, in order, within a single evaluation run).
_pair_signal = {i: 0 for i in range(len(PAIRS))}
_solo_signal = {idx: 0 for idx in SOLO_MEANREV}
_last_good_position = np.zeros(N_INST, dtype=int)


def _ols_hedge(a, b):
    """Closed-form OLS hedge ratio & intercept for a ~ hedge*b + const."""
    b_mean = b.mean()
    a_mean = a.mean()
    var = np.dot(b - b_mean, b - b_mean)
    if var < 1e-9:
        return None, None
    hedge = np.dot(b - b_mean, a - a_mean) / var
    const = a_mean - hedge * b_mean
    return hedge, const


def _run_strategy(prcSoFar):
    nInst, nDays = prcSoFar.shape
    positions = np.zeros(nInst, dtype=int)
    prices_today = prcSoFar[:, -1]

    # ---------------- Pair trades ----------------
    if nDays >= MIN_DAYS_PAIRS:
        for i, (idxA, idxB) in enumerate(PAIRS):
            pa = prcSoFar[idxA]
            pb = prcSoFar[idxB]

            w_hedge = min(HEDGE_WINDOW, nDays)
            hedge, const = _ols_hedge(pa[-w_hedge:], pb[-w_hedge:])
            if hedge is None or hedge <= 0:
                continue  # degenerate/untrustworthy fit this day; stay out

            if (idxA == 8) and (idxB == 27) and (nDays >= 100):
                garch_ok = False
                try:
                    returns_A = np.array(pd.Series(pa).pct_change().dropna())
                    returns_B = np.array(pd.Series(pb).pct_change().dropna())
                    modelA = arch_model(returns_A, mean='constant', vol='GARCH', p=1, q=1, rescale=False)
                    modelB = arch_model(returns_B, mean='constant', vol='GARCH', p=1, q=1, rescale=False)
                    garchA = modelA.fit(disp='off')
                    garchB = modelB.fit(disp='off')

                    A_forecast = np.sqrt(garchA.forecast(horizon=1).variance.values[-1, 0])
                    B_forecast = np.sqrt(garchB.forecast(horizon=1).variance.values[-1, 0])
                    garch_ok = True
                except Exception:
                    pass  # garch_ok stays False; static caps used below, A_forecast/B_forecast never read



            w_z = min(Z_WINDOW, nDays)
            spread_hist = pa[-w_z:] - hedge * pb[-w_z:] - const
            mu, sigma = spread_hist.mean(), spread_hist.std()
            if sigma < 1e-9:
                continue
            z = (spread_hist[-1] - mu) / sigma

            prev = _pair_signal[i]
            if z > ENTRY_Z:
                sig = -1
            elif z < -ENTRY_Z:
                sig = 1
            elif abs(z) < EXIT_Z:
                sig = 0
            else:
                sig = prev  # inside the band: hold whatever we had
            _pair_signal[i] = sig

            if sig == 0:
                continue

            price_a, price_b = prices_today[idxA], prices_today[idxB]
            cap_a = ALLOC_FRACTION * POSITION_LIMITS[idxA]
            cap_b = ALLOC_FRACTION * POSITION_LIMITS[idxB]

            if (idxA == 8) and (idxB == 27) and garch_ok:
                # Scale the OVERALL pair exposure with vol regime; ratio between legs
                # stays governed by `hedge` below, so the spread/z-score stay valid.
                combined_vol = A_forecast + B_forecast
                vol_scalar = np.clip(0.04120674924507828 / combined_vol, 0.3, 1.0)
                cap_a *= vol_scalar
                cap_b *= vol_scalar

            max_shares_a_from_a = np.floor(cap_a / price_a)
            max_shares_a_from_b = np.floor(cap_b / (hedge * price_b))
            shares_a = min(max_shares_a_from_a, max_shares_a_from_b)
            shares_b = np.floor(shares_a * hedge)

            positions[idxA] += sig * int(shares_a)
            positions[idxB] += -sig * int(shares_b)

    # ---------------- Solo mean-reversion ----------------
    if nDays >= MIN_DAYS_SOLO:
        for idx in SOLO_MEANREV:
            p = prcSoFar[idx]
            w = min(SOLO_WINDOW, nDays)
            window = p[-w:]
            mu, sigma = window.mean(), window.std()
            if sigma < 1e-9:
                continue
            z = (window[-1] - mu) / sigma

            prev = _solo_signal[idx]
            if z > SOLO_ENTRY_Z:
                sig = -1
            elif z < -SOLO_ENTRY_Z:
                sig = 1
            elif abs(z) < SOLO_EXIT_Z:
                sig = 0
            else:
                sig = prev
            _solo_signal[idx] = sig

            if sig == 0:
                continue

            price = prices_today[idx]
            cap = ALLOC_FRACTION * POSITION_LIMITS[idx]
            shares = int(np.floor(cap / price))
            positions[idx] = sig * shares

    return positions


def getMyPosition(prcSoFar):
    """
    prcSoFar: np.ndarray of shape (51, numDays), day (numDays-1) is most recent.
    Returns: 1D np.ndarray of 51 integers (target share positions).
    """
    global _last_good_position
    try:
        prcSoFar = np.asarray(prcSoFar, dtype=float)
        if prcSoFar.shape[0] != N_INST:
            return _last_good_position.copy()

        positions = _run_strategy(prcSoFar)
        positions = np.asarray(positions, dtype=int)
        _last_good_position = positions.copy()
        return positions
    except Exception:
        # Never let an unexpected error crash the submission mid-run.
        return _last_good_position.copy()